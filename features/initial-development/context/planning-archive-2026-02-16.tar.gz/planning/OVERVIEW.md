# Feature: VibePilot Skill

## Overview

Building the core `/vibepilot` skill for Claude Code that manages vibe engineering sessions.

## Scope

This feature encompasses:
- `/vibepilot start` command - initiate managed session
- `/vibepilot close` command - closeout with ADR generation
- Context monitoring and escalation suggestions
- Feature workspace scaffolding
- Context file verification and update guidance
- Integration with planning-with-files pattern

## Goals

1. Enable structured vibe sessions without forcing waterfall planning
2. Capture decisions and context updates systematically
3. Prevent context window degradation through proactive management
4. Maintain lean, high-value context files

## Non-Goals (for v1)

- Context sync tool (separate future feature)
- Automatic session promotion
- AI-decided closeout timing

## Open Questions

- Feature workspace location: root vs subdir?
- Exact context threshold percentages for escalation?
- ADR template format?
- Planning file templates to use?

## Success Criteria

- Can start/close vibe session via skill commands
- Feature workspace created with correct structure
- Planning artifacts consolidated on close
- Context file changes flagged for review
- Session summary and ADR persisted
