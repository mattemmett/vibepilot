# Decisions Log

## 2026-02-16: Architecture Pivot to Hooks + Scripts

**Context**: Initial implementation was prompt-only skill relying on Claude to remember to read/update context.

**Decision**: Rebuild with automation infrastructure:
- Hooks for lifecycle events
- CLI scripts for workspace management
- File-based state tracking

**Rationale**:
- Prompt-only can't capture/inject context automatically
- planning-with-files success proves hooks + automation pattern works
- Need deterministic behavior, not relying on agent memory

**Consequences**:
- More complex initial setup
- Better reliability during sessions
- Automatic context management
- Reusable across projects

---

## 2026-02-16: Own Implementation (Not Fork)

**Context**: planning-with-files exists and works well.

**Decision**: Build our own implementation, credit their work as inspiration.

**Rationale**:
- Different enough approach (feature workspaces, ADRs, context files)
- Want control over architecture decisions
- Learning by building

**Consequences**:
- Can't leverage their existing code
- More work upfront
- Full ownership and customization
- Must ensure proper credit/licensing

---

## 2026-02-16: Feature Workspace at Root

**Context**: Where to put `features/` directory?

**Decision**: Root level, not in `docs/` or subdirectory.

**Rationale**:
- Feature workspaces are active working spaces, not documentation
- Root-level visibility
- Simple paths for hooks and scripts

**Consequences**:
- Clean root structure
- Easy to find feature work
- Gitignore planning/ but keep decisions/ and context/

---

## 2026-02-16: Manual Closeout Only

**Context**: When to close a vibe session?

**Decision**: Manual trigger only (`/vibepilot close`), never automatic.

**Rationale**:
- User knows when they're done, agent doesn't
- Prevents premature closeout
- Avoids arguments about "are we done yet?"

**Consequences**:
- User must remember to close
- Could leave unclosed features (acceptable trade-off)
- Clean closeout process when it happens
