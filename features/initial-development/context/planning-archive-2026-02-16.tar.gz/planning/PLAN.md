# Implementation Plan

## ARCHITECTURE PIVOT

Initial approach was prompt-only skill. **Wrong.** Need actual automation infrastructure:
- **Skill**: Instructions for Claude
- **Hooks**: Automation at lifecycle events (SessionStart, PreToolUse, PostToolUse, Stop, PreCompact)
- **Scripts**: CLI utilities for workspace management
- **State tracking**: File-based session state

Inspiration from planning-with-files, but our own implementation.

---

## Phase 1: Core Infrastructure

### 1.1 Hook Scripts ⏳
- [ ] `hooks/session-start.sh` - Inject feature context on session start/resume
- [ ] `hooks/pre-tool-use.sh` - Re-read plans before major tool calls
- [ ] `hooks/post-tool-use.sh` - Capture outputs, prompt for status updates
- [ ] `hooks/stop.sh` - Verify completion before ending turn
- [ ] `hooks/pre-compact.sh` - Re-inject feature context before compaction

### 1.2 CLI Utilities ⏳
- [ ] `bin/vibe-start` - Create feature workspace, initialize files, set active feature
- [ ] `bin/vibe-close` - Generate ADR, consolidate planning, update context files
- [ ] `bin/vibe-status` - Show active feature, progress, context usage
- [ ] `bin/vibe-context-check` - Verify context files vs code changes

### 1.3 State Management ⏳
- [ ] `.vibe/active-feature` - Track current feature workspace
- [ ] `.vibe/session.json` - Session metadata (start time, goals, context usage)
- [ ] Feature metadata in `features/<name>/.vibe-meta.json`

### 1.4 Skill File Updates ⏳
- [ ] Rewrite `skills/vibepilot.md` to work with hooks/scripts
- [ ] Add instructions for when hooks inject context
- [ ] Define handoff between skill and automation

## Phase 2: Hook Configuration

### 2.1 Hooks Setup ⏳
- [ ] Create `hooks/hooks.json` for plugin packaging
- [ ] Define SessionStart matcher for startup/resume
- [ ] Define PreToolUse matcher for Read/Write/Edit/Bash
- [ ] Define PostToolUse for capturing changes
- [ ] Define Stop hook for completion verification
- [ ] Define PreCompact for context re-injection

### 2.2 Testing Hooks ⏳
- [ ] Test SessionStart injection with debug mode
- [ ] Verify PreToolUse reads planning files
- [ ] Confirm PostToolUse captures tool outputs
- [ ] Validate Stop hook completion checks
- [ ] Test PreCompact re-injection

## Phase 3: Integration

### 3.1 End-to-End Flow ⏳
- [ ] `/vibepilot start` → calls bin/vibe-start → hooks take over
- [ ] Working session → hooks manage context automatically
- [ ] `/vibepilot close` → calls bin/vibe-close → ADR generation
- [ ] Context compaction → PreCompact re-injects feature context

### 3.2 Context File Management ⏳
- [ ] Detect changes to agents.md locations (root + subdirs)
- [ ] Detect changes affecting architecture.md
- [ ] Detect changes affecting product.md
- [ ] Flag conflicts/extensions on close
- [ ] Suggest minimal, precise updates

## Phase 4: Polish

### 4.1 Documentation ⏳
- [ ] Update installation guide for hooks + scripts
- [ ] Create troubleshooting guide
- [ ] Document hook debugging with `claude --debug`
- [ ] Add example workflows

### 4.2 Packaging ⏳
- [ ] Package as installable plugin
- [ ] Include credits to planning-with-files inspiration
- [ ] License (MIT)
- [ ] Distribution via GitHub

---

## Key Decisions

✅ **Architecture**: Skill + Hooks + Scripts (not prompt-only)
✅ **State tracking**: File-based (`.vibe/` directory)
✅ **Feature workspace**: `features/<name>/` at root
✅ **Planning files**: OVERVIEW, PLAN, PROGRESS, DECISIONS
✅ **Closeout**: Manual trigger, automated ADR generation
✅ **Context injection**: Automatic via hooks, not manual prompts

## Technical Constraints

- Hooks must be fast (<1s for SessionStart)
- Scripts use bash for portability
- JSON for structured data
- Exit codes: 0 = proceed, 2 = block + show error
- All file paths quoted for spaces
